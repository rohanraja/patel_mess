## 1.0.2

- Added library option

## 1.0.1

- Added support for Highcharts 2.1+
- Fixed sorting for line chart with multiple series and Google Charts

## 1.0.0

- First major release
